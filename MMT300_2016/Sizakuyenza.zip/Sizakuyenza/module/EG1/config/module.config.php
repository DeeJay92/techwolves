<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action'     => 'index',
                    ),
                ),
            ),
            'display' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/display',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'display',
                    ),
                ),
            ),
            'about' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/about',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'about',
                    ),
                ),
            ),
            'gallery' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/gallery',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'gallery',
                    ),
                ),
            ),
           'history' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/history',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'history',
                    ),
                ),
            ),'mission' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/mission',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'mission',
                    ),
                ),
            ),
            'services' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/services',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'services',
                    ),
                ),
            ),
            'our-supporters' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/our-supporters',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'our-supporters',
                    ),
                ),
            ),
             'event' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/event',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'event',
                    ),
                ),
            ),
            'blog' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/blog',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'blog',
                    ),
                ),
            ),
             'get-involved' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/get-involved',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'get-involved',
                    ),
                ),
            ),
            'contact' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/contact',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'contact',
                    ),
                ),
            ),
               'newsletter' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/newsletter',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'newsletter',
                    ),
                ),
            ),
      'register' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/register',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'register',
                    ),
                ),
            ),

             'login' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/login',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'login',
                    ),
                ),
            ),
            

            'thank-you' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/thank-you',
                    'defaults' => array(
                        'controller' => 'EG1\Controller\Index',
                        'action' => 'thank-you',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'EG1' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/EG1',
                    'defaults' => array(
                        '__NAMESPACE__' => 'EG1\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
                
                    
                
                
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/[:controller[/:action]]',
                            'constraints' => array(
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    'service_manager' => array(
        'abstract_factories' => array(
            'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
            'Zend\Log\LoggerAbstractServiceFactory',
        ),
        'aliases' => array(
            'translator' => 'MvcTranslator',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'EG1\Controller\Index' => 'EG1\Controller\IndexController',
          
        ),
    ),
     
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'application/index/index' => __DIR__ . '/../view/application/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
    // Placeholder for console routes
    'console' => array(
        'router' => array(
            'routes' => array(
            ),
        ),
    ),
);

