<h1>Login Successful</h1>

<p>
    <div class="alert alert-success">
        <p>Welcome: <?php echo $this->user_email; ?></p>
    </div>
</p>
<a class="backHome" href="<?php echo $this->url('home') ?>"><?php echo $this->translate('<< Back to Home') ?></a>

