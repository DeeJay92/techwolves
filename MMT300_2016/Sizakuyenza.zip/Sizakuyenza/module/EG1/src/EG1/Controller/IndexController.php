<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace EG1\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use EG1\Form\CustomerForm; 
use EG1\Model\Customer;
use EG1\Form\LoginForm; 
use EG1\Model\Login;

use EG1\Form\ContactForm;

use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\CustmerTable as DbTableAuthAdapter;

class IndexController extends AbstractActionController
{
    protected $customerTable;
    public function getCustomerTable()
    {
         if (!$this->customerTable) {
             $sm = $this->getServiceLocator();
             $this->customerTable = $sm->get('EG1\Model\CustomerTable');
         }
         return $this->customerTable;
     }
  //added by dj  
 public function getAuthService()
{
 if (! $this->authservice) {
 $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\
Adapter');
 $dbTableAuthAdapter = new DbTableAuthAdapter($dbAdapter,
'user','email','password', 'MD5(?)');
 $authService = new AuthenticationService();
 $authService->setAdapter($dbTableAuthAdapter);
 $this->authservice = $authService;
 }
 return $this->authservice;
} 
     
//    protected $loginTable;
//    public function getLoginTable()
//    {
//         if (!$this->loginTable) {
//             $sm = $this->getServiceLocator();
//             $this->loginTable = $sm->get('EG1\Model\LoginTable');
//         }
//         return $this->loginTable;
//     }     
//     
    public function indexAction()
    {
        return new ViewModel();
    }
    
     public function displayAction()
    {
       
       $name = "Pepukayi";
       return new ViewModel(
               array("Name"  => $name,)
               );
    }
    
    public function aboutAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    
    public function galleryAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    public function historyAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    public function missionAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    public function servicesAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    public function eventAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    public function getInvolvedAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
     public function blogAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
     public function contactAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
         public function newsletterAction()
    {
        //$this->layout()->setTemplate('layout/layout2');
        return new ViewModel();
    }
    
   public function registerAction()  //form that we created in class
    {
        $form = new CustomerForm();
        
        if($this->getRequest()->isPost()) {
            
            // Fill in the form with POST data
            $data = $this->params()->fromPost();            
            
            $form->setData($data);
            echo $data['email'];
            
            // Validate form
            if($form->isValid()) {
                
                // Get filtered and validated data
                $data = $form->getData();
                echo $data['email'];
                $customer = new Customer();
                $customer->exchangeArray($data);
                echo $customer->usr_email;
                /*$email = $data['email'];
                $name = $data['name'];
                $password = $data['password'];*/
                
                //$customer->exchangeArray($form->getData());
                $this->getCustomerTable()->saveCustomer($customer);
                
                // Redirect to "Thank You" page
                return $this->redirect()->toRoute('EG1/default', 
                        array('controller'=>'index', 'action'=>'newUser'));
            }               
        } 
        
        return new ViewModel(
                array(
            'form' => $form
        ));
    }
    
   public function loginAction(){  //form that we created in class
    
        $form = new LoginForm();
        
        if($this->getRequest()->isPost()) {
            
            // Fill in the form with POST data
            $data = $this->params()->fromPost();            
            
            $form->setData($data);
            echo $data['email'];
            
            // Validate form
            if($form->isValid()) {
                
                // Get filtered and validated data
                $data = $form->getData();
                echo $data['email'];
                $login = new Login();
                $login->exchangeArray($data);
                echo $login->usr_email;
                /*$email = $data['email'];
                $name = $data['name'];
                $password = $data['password'];*/
                
                $login->exchangeArray($form->getData());
//                $this->CustomerTable()->saveLogin($login);
                
                // Redirect to "Thank You" page
                return $this->redirect()->toRoute('EG1/default', 
                        array('controller'=>'index', 'action'=>'logSuccess'));
            }               
        } 
        
        return new ViewModel(
                array(
            'form' => $form
        ));
   }     
        public function processAction(){
//
$this->getAuthService()->getAdapter()
 ->setIdentity($this->request->getPost('email')) ->setCredential
        ($this->request->getPost('password'));
$result = $this->getAuthService()->authenticate();
if ($result->isValid()) {
 $this->getAuthService()->getStorage()->write($this->request->getPost('email'));
 return $this->redirect()->toRoute(NULL , array(
 
 'action' => 'confirm'
 ));
}

    }    
   
      
     public function newuserAction(){
        return new ViewModel();
     }
     public function logsuccessAction(){
//        return new ViewModel();
          
 $usr_email = $this->getAuthService()->getStorage()->read();
 $viewModel = new ViewModel(array(
 'usr_email' => $usr_email
 ));
 return $viewModel;
 }
 
     public function contactusAction()
    {
        // Check if user has submitted the form
         // Create Contact Us form
        $form = new ContactForm();
        
        // Check if user has submitted the form
        if($this->getRequest()->isPost()) {
            
            // Fill in the form with POST data
            $data = $this->params()->fromPost();            
            
            $form->setData($data);
            
            
            // Validate form
            if($form->isValid()) {
                
                // Get filtered and validated data
                $data = $form->getData();
                
                $customer = new Customer();
                $customer->exchangeArray($data);
                /*$email = $data['email'];
                $subject = $data['subject'];
                $body = $data['body'];
                $payment = $data['payment'];*/
                
                //$customer->exchangeArray($form->getData());
                $this->getCustomerTable()->saveCustomer($customer);
                
                
                /*// Send E-mail
                $mailSender = new MailSender();
                if(!$mailSender->sendMail('no-reply@example.com', $email, $subject, $body)) {
                    // In case of error, redirect to "Error Sending Email" page
                    return $this->redirect()->toRoute('application/default', 
                        array('controller'=>'index', 'action'=>'sendError'));
                }*/
                
                // Redirect to "Thank You" page
                return $this->redirect()->toRoute('application/default', 
                        array('controller'=>'index', 'action'=>'thankYou'));
            }               
        } 
        
        // Pass form variable to view
        return new ViewModel(array(
            'form' => $form
        ));
    }
 }
    

