<?php

namespace EG1\Model;

class Login
{
    public $usr_id;
    public $usr_email;
    public $usr_password;
        
    public function exchangeArray($data)
     {
         $this->usr_id     = (!empty($data['usr_id'])) ? $data['usr_id'] : null;
         $this->usr_email  = (!empty($data['email'])) ? $data['email'] : null;
         $this->usr_password  = (!empty($data['password'])) ? $data['password'] : null;        
     }
}

