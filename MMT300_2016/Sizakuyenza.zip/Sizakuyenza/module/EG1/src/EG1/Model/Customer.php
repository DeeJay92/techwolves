<?php

namespace EG1\Model;



class Customer
{
    public $usr_id;
    public $usr_name;
    public $usr_password;
    public $usr_email;
    
    public function exchangeArray($data)
     {
         $this->usr_id     = (!empty($data['usr_id'])) ? $data['usr_id'] : null;
         $this->usr_name = (!empty($data['Name'])) ? $data['Name'] : null;
         $this->usr_password  = (!empty($data['password'])) ? $data['password'] : null;
         $this->usr_email  = (!empty($data['email'])) ? $data['email'] : null;
     }
}
